function gerarCurriculo(){
const ids=['nome','telefone','email','objetivo','experiencia','formacao','cursos','habilidades'];
const v={}; ids.forEach(i=>v[i]=document.getElementById(i).value);
document.getElementById('resultado').innerHTML=`
<h2>${v.nome}</h2>
<p><b>Telefone:</b> ${v.telefone}</p>
<p><b>E-mail:</b> ${v.email}</p>
<h3>Objetivo</h3><p>${v.objetivo}</p>
<h3>Experiência</h3><p>${v.experiencia}</p>
<h3>Formação</h3><p>${v.formacao}</p>
<h3>Cursos</h3><p>${v.cursos}</p>
<h3>Habilidades</h3><p>${v.habilidades}</p>`;
}
