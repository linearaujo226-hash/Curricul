
function gerar(){
let g=id=>document.getElementById(id).value;
document.getElementById('resultado').innerHTML=`
<h1>${g('nome')}</h1>
<h3>${g('cargo')}</h3>
<p>${g('telefone')} | ${g('email')}</p>
<hr>
<h2>Resumo</h2><p>${g('resumo')}</p>
<h2>Experiência</h2><p>${g('experiencia')}</p>
<h2>Formação</h2><p>${g('formacao')}</p>
`;
}
